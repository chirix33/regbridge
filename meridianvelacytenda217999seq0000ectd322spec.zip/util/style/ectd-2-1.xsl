<!-- Non-normative local stub. See the ICH M2 EWG eCTD stylesheet package
     for the authoritative stylesheet. -->
